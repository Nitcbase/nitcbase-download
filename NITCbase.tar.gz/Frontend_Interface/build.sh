mkdir build
cd build
cmake ..
make
cp Frontend-Interface ../
cd ..
rm -rf build/