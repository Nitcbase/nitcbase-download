//
// Created by Gokul on 05/02/22.
//
#include <iostream>
#include <fstream>

using namespace std;
int main() {
    ofstream myFile("sample125attrs.csv");
    for(int i=0; i<130; i++) {
        myFile << "attr" << i << ",";
    }
    myFile << endl;
    for(int i=0; i<130; i++) {
        myFile << i << ",";
    }
}