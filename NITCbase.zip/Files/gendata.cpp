//
// Created by Gokul on 05/02/22.
//
#include <iostream>
using namespace std;
int main() {
    cout << "CREATE TABLE newBig(";
    for(int i=0; i<130; i++) {
        cout << "attr" << i << " STR, ";
    }
    cout << ");" << endl;
}