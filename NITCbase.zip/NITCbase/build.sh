#!/bin/sh

echo Building docker image xfs

docker build . -t xfs