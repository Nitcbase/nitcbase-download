DIR="./NITCbase/"
if [ -d "$DIR" ]; then
	# Take action if $DIR exists. #
	echo "ERROR: $DIR directory already exists. If you want to install a fresh copy, remove the existing directory and retry."
else
	echo Downloading the NTCbase package...
	wget https://github.com/Nitcbase/nitcbase/archive/master.tar.gz
	echo Extracting the package...
	tar -xvzf master.tar.gz
	rm master.tar.gz
	mkdir NITCbase
	cp -a nitcbase-master/. NITCbase/
	rm -rf nitcbase-master
	echo NITCbase package installed. Checkout the directories and files present at https://nitcbase.github.io/nitcbase-documentation-v2/docs/XFS%20Interface/Installation%20Guidelines#files-and-directories
fi
