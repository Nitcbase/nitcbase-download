mkdir build
cd build
cmake ..
make
cp Frontend-Interfacee ../
cd ..
rm -rf build/