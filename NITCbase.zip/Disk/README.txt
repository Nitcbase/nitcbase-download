A Binary File in which disk for NITCbase is simulated
NITCBase Filesystem is present inside this "disk" binary file
