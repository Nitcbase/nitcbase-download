mkdir build
cd build
cmake ..
make
cp XFS-Interface ../
cd ..
rm -rf build/